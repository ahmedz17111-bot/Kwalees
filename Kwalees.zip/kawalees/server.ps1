# Kawalees local server - By Abu Faisal
$port = 8765
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$port/")
try { $l.Start() } catch { Start-Process "http://localhost:$port/"; exit }
Start-Process "http://localhost:$port/"
Write-Host "Kawalees is running on http://localhost:$port"
Write-Host "Keep this window open while you use the site. Close it to stop."
$mime = @{'.html'='text/html; charset=utf-8';'.js'='text/javascript';'.css'='text/css';'.wasm'='application/wasm';'.json'='application/json';'.png'='image/png';'.svg'='image/svg+xml';'.ico'='image/x-icon'}
while ($l.IsListening) {
  $ctx = $l.GetContext(); $req = $ctx.Request; $res = $ctx.Response
  try {
    $p = [Uri]::UnescapeDataString($req.Url.AbsolutePath.TrimStart('/'))
    if ($p -eq '') { $p = 'index.html' }
    $full = [IO.Path]::GetFullPath((Join-Path $root $p))
    if (-not $full.StartsWith($root) -or -not (Test-Path -LiteralPath $full -PathType Leaf)) { $res.StatusCode = 404 }
    else {
      $ext = [IO.Path]::GetExtension($full).ToLower()
      if ($mime.ContainsKey($ext)) { $res.ContentType = $mime[$ext] } else { $res.ContentType = 'application/octet-stream' }
      $b = [IO.File]::ReadAllBytes($full); $res.ContentLength64 = $b.Length; $res.OutputStream.Write($b, 0, $b.Length)
    }
  } catch {} finally { $res.Close() }
}
