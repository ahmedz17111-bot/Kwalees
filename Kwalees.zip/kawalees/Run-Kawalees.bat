@echo off
title Kawalees
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
